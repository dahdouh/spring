package com.ex4.springSOAP;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringSoapApplicationTests {

	@Test
	void contextLoads() {
	}

}
