package com.spring.karim.restful.model;

import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;

import lombok.Data;

@Data
@Entity
public class Qcm {
	
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	public int id;
	public String question;
	public String listchoices;
	public String response;
	@ManyToOne(fetch = FetchType.EAGER)
	public Exercice exercice;

}
