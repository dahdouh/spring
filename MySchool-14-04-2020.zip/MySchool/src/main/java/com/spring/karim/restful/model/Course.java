package com.spring.karim.restful.model;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToMany;
import javax.persistence.OneToMany;

import org.hibernate.annotations.Fetch;
import org.hibernate.annotations.FetchMode;

import lombok.Data;

@Data
@Entity
public class Course {

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	public int id;
	public String libelle;
	public String progress;
	@ManyToMany(mappedBy="courses")
	private List<User> users;
	@OneToMany(mappedBy="course", fetch = FetchType.EAGER)
	@Fetch(value = FetchMode.SUBSELECT)
	public List<CourseContent> contents;
	@OneToMany(mappedBy="course", fetch = FetchType.EAGER)
	@Fetch(value = FetchMode.SUBSELECT)
	public List<Exercice> exercices;
}
