package com.spring.karim.restful.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;

import com.spring.karim.restful.model.LogSession;

public interface LogSessionRepository extends CrudRepository<LogSession, Integer>, JpaRepository<LogSession, Integer> {

	@Query("SELECT s FROM LogSession s WHERE s.user.id = :userconnectedId AND s.dateDeconnexion is null")
	LogSession getSessionByUserLogin(@Param("userconnectedId") int userconnectedId);
	
	
}

