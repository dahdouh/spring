package com.spring.karim.restful.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.spring.karim.restful.model.Course;
import com.spring.karim.restful.model.CourseContent;
import com.spring.karim.restful.model.Exercice;
import com.spring.karim.restful.repository.CourseContentRepository;
import com.spring.karim.restful.repository.CourseRepository;
import com.spring.karim.restful.repository.ExerciceRepository;

@RestController
@RequestMapping("/api")
public class CourseController {

	@Autowired
	private CourseRepository courseRepository;
	@Autowired
	private CourseContentRepository courseContentRepository;
	@Autowired
	private ExerciceRepository exerciceRepository;
	
	@RequestMapping("/cours/maths")
	public List<Course> get(){
		return courseRepository.get();
		
	}
	@RequestMapping("/cours")
	public List<Course> getCours(){
		return courseRepository.get();
		
	}
	@RequestMapping("/cours/contenu")
	public List<CourseContent> getContent(){
		return courseContentRepository.getContent();
	}
	@RequestMapping("/cours/exercice")
	public List<Exercice> getExercice(){
		return exerciceRepository.getExerice();
	}
	@RequestMapping("/cours/{libelle}")
	public List<Course> getRecherche(@PathVariable String libelle){
		return courseRepository.get(libelle);
	}
	@RequestMapping("/cours/contenu/{course_id}")
	public List<CourseContent> getContent(@PathVariable int course_id){
		return courseContentRepository.getContent(course_id);
	}
	@RequestMapping("/cours/exercice/{course_id}")
	public List<Exercice> getExercice(@PathVariable int course_id){
		return exerciceRepository.getExerice(course_id);
	}
	@RequestMapping("/cours/contenu/{course_id}/{type}")
	public List<CourseContent> getContent(@PathVariable int course_id,@PathVariable int type){
		return courseContentRepository.getContent(course_id,type);
	}
}
