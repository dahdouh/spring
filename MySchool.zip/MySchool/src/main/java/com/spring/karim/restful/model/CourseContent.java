package com.spring.karim.restful.model;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;

import org.hibernate.annotations.LazyCollection;
import org.hibernate.annotations.LazyCollectionOption;

import lombok.Data;

@Data
@Entity
public class CourseContent {
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	public int id;
	public String title;
	public String type;
	public String path;
	@ManyToOne(
		    fetch = FetchType.LAZY
		)
	//@LazyCollection(LazyCollectionOption.TRUE)
	public Course course;
	
}
