package com.spring.karim.restful.model;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToMany;
import javax.persistence.OneToMany;

import org.hibernate.annotations.Fetch;
import org.hibernate.annotations.FetchMode;
import org.hibernate.annotations.LazyCollection;
import org.hibernate.annotations.LazyCollectionOption;

import lombok.Data;

@Data
@Entity
public class Course {

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	public int id;
	public String libelle;
	public String progress;
	public String level;
	public String description;
	public String image;
	@ManyToMany(mappedBy="courses")
	private List<User> users;
	@OneToMany(fetch = FetchType.LAZY, mappedBy="course")
	//@Fetch(value = FetchMode.SUBSELECT)
	//@LazyCollection(LazyCollectionOption.FALSE)
	public List<CourseContent> contents;
	@OneToMany(fetch = FetchType.LAZY, mappedBy="course")
	//@Fetch(value = FetchMode.SUBSELECT)
	//@LazyCollection(LazyCollectionOption.FALSE)
	public List<Exercice> exercices;
	
	
}
