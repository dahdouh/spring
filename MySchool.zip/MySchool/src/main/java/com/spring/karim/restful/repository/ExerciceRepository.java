package com.spring.karim.restful.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.spring.karim.restful.model.Exercice;

@Repository
public interface ExerciceRepository extends CrudRepository<Exercice, Integer>, JpaRepository<Exercice, Integer> {

	@Query("SELECT ex FROM Exercice ex")
	List<Exercice> getExerice();
	
	@Query("SELECT ex FROM Exercice ex WHERE ex.course.id = :course_id")
	List<Exercice> getExerice(@Param("course_id") int course_id);
}
