package com.spring.karim.restful.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.spring.karim.restful.model.CourseContent;

@Repository
public interface CourseContentRepository extends CrudRepository<CourseContent, Integer>, JpaRepository<CourseContent, Integer> {

	@Query("SELECT cc FROM CourseContent cc")
	List<CourseContent> getContent();
	
	@Query("SELECT cc FROM CourseContent cc WHERE cc.course.id = :course_id")
	List<CourseContent> getContent(@Param("course_id") int course_id);    
    
	@Query("SELECT cc FROM CourseContent cc WHERE cc.course.id = :course_id AND cc.type = :type")
	List<CourseContent> getContent(@Param("course_id") int course_id, @Param("type") int type);
}
