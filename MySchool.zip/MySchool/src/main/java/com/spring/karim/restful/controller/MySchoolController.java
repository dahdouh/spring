package com.spring.karim.restful.controller;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import com.spring.karim.restful.model.Compte;
import com.spring.karim.restful.model.LogSession;
import com.spring.karim.restful.model.Profile;
import com.spring.karim.restful.model.User;
import com.spring.karim.restful.repository.CompteRepository;
import com.spring.karim.restful.repository.LogSessionRepository;
import com.spring.karim.restful.repository.ProfileRepository;
import com.spring.karim.restful.repository.UserRepository;
import com.spring.karim.restful.service.EmailService;
import com.spring.karim.restful.service.EmailServiceImpl;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

@RestController
public class MySchoolController {
	
	Logger logger = LoggerFactory.getLogger(MySchoolController.class);
	
	@Autowired
	public EmailService emailService = new EmailServiceImpl();
	@Autowired
	public UserRepository userRepository;
	@Autowired
	public CompteRepository compteRepository;
	@Autowired
	public ProfileRepository profileRepository;
	@Autowired
	public LogSessionRepository logSessionRepository;
	
	/*------------------------- registration  ------------------------*/
	@GetMapping("/register/{login}/{password}/{firstname}/{lastname}/{email}/{facebook}/{twitter}")
	public User registration(@PathVariable String login, @PathVariable String password, @PathVariable String firstname, @PathVariable String lastname, @PathVariable String email, @PathVariable String facebook, @PathVariable String twitter) {
		User user = new User(firstname, lastname, email, facebook, twitter);
		if(!login.equals("") && !password.equals("") && !firstname.equals("") && !lastname.equals("") && !email.equals("") && !facebook.equals("") && !twitter.equals("")) {
			
			Compte compteExist = null;
			compteExist = compteRepository.getCompteByLogin(login);
			User userByEmail = userRepository.getUserByEmail(email);
			if(compteExist != null || userByEmail != null) {
				user.setFirstname("already exist");
				logger.info("Compte ! " + user.getFirstname());
				
			} else {
				user.setFirstname(firstname);
				user.setLastname(lastname);
				user.setEmail(email);
				user.setFacebook(facebook);
				user.setTwitter(twitter);
				
				Compte compte = new Compte(login, password);
				Profile profile = new Profile();
				profile = profileRepository.getProfileByRole("ROLE_PARENT");
				compte.setProfile(profile);
				compte.setActivate("no");
				compteRepository.save(compte);	
				
				user.setCompte(compte);
				userRepository.save(user);
				//String url = "https://onlineschool.cfapps.io/activateAccount/"+user.getId();
				String url = "http://192.168.43.203:8085/activateAccount/"+user.getId();
				
				emailService.sendSimpleMessage(email, "Online school registration", "Hi "+user.getLastname()+", thank you for your registration in our online school courses. "
						+ "In order to activate your account please click in this link: "+url);
				logger.info("utilisateur est bien enregistré");
				
				
			}
		}
		
		return user;
	}
	
	/*------------------------- new student  ------------------------*/
	@GetMapping("/student/{userconnected}/{login}/{password}/{firstname}/{lastname}/{parent}/{level}")
	public User addStudent(@PathVariable String userconnected, @PathVariable String firstname, @PathVariable String login, @PathVariable String password, @PathVariable String lastname, @PathVariable String parent, @PathVariable String level) {
		User user = new User(firstname, lastname, level, parent);
		if(!firstname.equals("") && !lastname.equals("") && !parent.equals("") && !level.equals("")) {
			
			User student_parent = null;
			student_parent = userRepository.getUserByEmail(userconnected);
			if(student_parent == null) {
				System.out.println("######################### user not Exist "+ student_parent.getFirstname());
				user.setFirstname("user not exist");
				logger.info("user not exist!");
				
			} else {
				user.setParent(student_parent);
				//compteRepository.save(new Compte(login, password));
				Compte compte = new Compte();
				Profile profile = profileRepository.getProfileById(2);			
				compte.setProfile(profile);
				compte.setLogin(login);
				compte.setPassword(password);
				compte.setActivate("yes");
				user.setCompte(compte);
				userRepository.save(user);
				/*---------------- send email, contains students login and password, to parent ------------*/
				emailService.sendSimpleMessage(student_parent.getEmail(), "Online school registration", "Hi "+ student_parent.getLastname() +", We would to inform you that  your child registration is successfully done. To connect to the new account, please use "+login+" as username and "+ password +" as password.");
				logger.info("student has been successfully registred");
			}
		}
		
		return user;
	}
	
	/*------------------------- list students  ------------------------*/
	@GetMapping("/students/{userconnected}")
	public List<User> getStudents(@PathVariable int userconnected) {
		List<User> students = new ArrayList<User>();
		students = userRepository.getStudentsByParent(userconnected);				
		for (User user : students) {
			System.out.println("########################## "+ user.getFirstname());
		}
		return students;
	}
	
	
	
	/*------------------------- Login: Authentification  ------------------------*/
	@GetMapping("/auth/{login}/{password}")
	public User authentification(@PathVariable String login, @PathVariable String password) {
		User user = new User();
		Compte compte = null;
		if(!login.equals("") && !password.equals("")) {
			
			compte = compteRepository.authentification(login, password);
			if(compte != null) {
				user = userRepository.getUserByCompteId(compte.getId());
				LogSession logSession = new LogSession(new Date(), user);
				logSessionRepository.save(logSession);
				logger.info("authentification ok!");
			} else {
				user.setFirstname("not found");
				System.out.println("????????????????????????????????? authentification failed");
			}
			
			if(user != null) 
			logger.info("authentification ok!");
		}
		
		return user;
	}
	
	/*------------------------- Logout  ------------------------*/
	@GetMapping("/logout/{userconnectedId}")
	public LogSession logout(@PathVariable int userconnectedId) {
		LogSession logSession = null;

			logSession = logSessionRepository.getSessionByUserLogin(userconnectedId);
			if(logSession != null) {
				
				logSession.setDateDeconnexion(new Date());
				logSessionRepository.save(logSession);
				logger.info("logout ok!");
			}else {
				User user = logSession.getUser();
				user.setFirstname("not found");
				logSession.setUser(user);
			}
		return logSession;
	}
	
	/*-------------------------   confirmation of registration by email   ------------------------*/
	@GetMapping("/sendMail")
	public void sendMail(User user) {
		  emailService.sendSimpleMessage("karim.dahdouh.fr@gmail.com", "Online school registration", "Hi "+user.getLastname()+", thank you for your registration in our online school courses.");
		  /*=emailService.sendMessageWithAttachment("karim.dahdouh.fr@gmail.com", "Online school registration", "Hi, thank you for your registration in our online school courses",
				  									"/home/karim/Downloads/EcoleEnLigne.pdf");
	      */
	}
	
	/*-------------------------  send password   ------------------------*/
	@GetMapping("/sendPassword/{email}")
	public User sendPassword(@PathVariable String email, Model model) {
		  User user = null;
		  user = userRepository.getUserByEmail(email);
		  if(user != null) {
			  emailService.sendSimpleMessage(email, "Recover your password", "Hi, You have requested a new password. To access the MySchool application, you can use the following coordinates: login ("+ user.getCompte().getLogin() +") and password ("+ user.getCompte().getPassword() +").");;
			  logger.info("mot de passe à bien été envoyé à l'adresse mail indiquée. ");
			} else {
				user.setFirstname("email not found");
				logger.info("mot de passe à bien été envoyé à l'adresse mail indiquée. ");
			}
		  
		  
	    return user;
	}
	

}
