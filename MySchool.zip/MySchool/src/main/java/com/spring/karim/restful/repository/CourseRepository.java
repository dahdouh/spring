package com.spring.karim.restful.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.spring.karim.restful.model.Course;
import com.spring.karim.restful.model.CourseContent;
import com.spring.karim.restful.model.Exercice;

@Repository
public interface CourseRepository extends CrudRepository<Course, Integer>, JpaRepository<Course, Integer> {
	
	@Query("SELECT c FROM Course c")
	List<Course> get();
		
    
    @Query("SELECT c FROM Course c WHERE c.id = :id")    
	Course get(@Param("id") int id);  
    
    @Query("SELECT c FROM Course c WHERE c.id = :title")
	List<Course> get(@Param("title") String title);

}
