package io.spring.ex4.webservice;

import lombok.Data;

@Data
public class Comparateur {

 protected String nomHotel;
 protected String adresseHotel;
 protected int nombreEtoile;
 protected String idChambre;
 protected int nombreLits;
 protected String nomAgenceVoyage;

}
