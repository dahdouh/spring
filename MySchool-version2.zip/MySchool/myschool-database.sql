-- MySQL dump 10.13  Distrib 5.7.29, for Linux (x86_64)
--
-- Host: localhost    Database: myschool
-- ------------------------------------------------------
-- Server version	5.7.29-0ubuntu0.18.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `compte`
--

DROP TABLE IF EXISTS `compte`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `compte` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `login` varchar(255) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  `profile_id` int(11) DEFAULT NULL,
  `activate` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FKmmhw4hs6ep09qqjm6cn8a0cyn` (`profile_id`),
  CONSTRAINT `FKmmhw4hs6ep09qqjm6cn8a0cyn` FOREIGN KEY (`profile_id`) REFERENCES `profile` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=55 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `compte`
--

LOCK TABLES `compte` WRITE;
/*!40000 ALTER TABLE `compte` DISABLE KEYS */;
INSERT INTO `compte` VALUES (25,'karim','karim@1',1,'yes'),(26,'null','null',1,'no'),(27,'null','null',NULL,'no'),(28,'test333','test333',1,'no'),(29,'test333','test333',NULL,'no'),(30,'test4','test4T',1,'no'),(31,'test4','test4T',1,'no'),(32,'p5','p5@1',1,'no'),(33,'p5','p5@1',1,'no'),(34,'yan','yanis@1',1,NULL),(35,'yanooo','yanis@1ooo',1,NULL),(36,'yanppp','yanis@1oooPPP',1,'no'),(37,'yanOPPPP','yanis@1oooPPP',1,'no'),(38,'ooopk','yanokp@',1,'yes'),(39,'kkdd','jjk@2',NULL,NULL),(40,'kkddz','jjk@2',NULL,NULL),(41,'test5','test5',NULL,NULL),(42,'test6','test@1',NULL,NULL),(43,'test7','test7@',NULL,NULL),(44,'test8','test8@',1,'no'),(45,'test9','test@9',1,'no'),(46,'test99','test@9',1,'yes'),(47,'test10','test10@',1,'no'),(48,'test100','test10@',1,'no'),(49,'barry','barry',1,'no'),(50,'barry1','barry1',1,'yes'),(51,'barry3','barry3',1,'no'),(53,'barry5','barry5',1,'yes'),(54,'barry52','barry52',1,'yes');
/*!40000 ALTER TABLE `compte` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `course`
--

DROP TABLE IF EXISTS `course`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `course` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `libelle` varchar(255) DEFAULT NULL,
  `progress` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `course`
--

LOCK TABLES `course` WRITE;
/*!40000 ALTER TABLE `course` DISABLE KEYS */;
/*!40000 ALTER TABLE `course` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `course_content`
--

DROP TABLE IF EXISTS `course_content`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `course_content` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `path` varchar(255) DEFAULT NULL,
  `title` varchar(255) DEFAULT NULL,
  `type` varchar(255) DEFAULT NULL,
  `course_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FKknr61ctevkwqhoxi6wpem4dk6` (`course_id`),
  CONSTRAINT `FKknr61ctevkwqhoxi6wpem4dk6` FOREIGN KEY (`course_id`) REFERENCES `course` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `course_content`
--

LOCK TABLES `course_content` WRITE;
/*!40000 ALTER TABLE `course_content` DISABLE KEYS */;
/*!40000 ALTER TABLE `course_content` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `exercice`
--

DROP TABLE IF EXISTS `exercice`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exercice` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `libelle` varchar(255) DEFAULT NULL,
  `note` double NOT NULL,
  `course_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FKqqxsl3g04gfcxxut6wnr782l8` (`course_id`),
  CONSTRAINT `FKqqxsl3g04gfcxxut6wnr782l8` FOREIGN KEY (`course_id`) REFERENCES `course` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exercice`
--

LOCK TABLES `exercice` WRITE;
/*!40000 ALTER TABLE `exercice` DISABLE KEYS */;
/*!40000 ALTER TABLE `exercice` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `log_activity`
--

DROP TABLE IF EXISTS `log_activity`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `log_activity` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date_activity` datetime(6) DEFAULT NULL,
  `libelle` varchar(255) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FKe2pv8h1erkw0r69yvowo6plj5` (`user_id`),
  CONSTRAINT `FKe2pv8h1erkw0r69yvowo6plj5` FOREIGN KEY (`user_id`) REFERENCES `user` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `log_activity`
--

LOCK TABLES `log_activity` WRITE;
/*!40000 ALTER TABLE `log_activity` DISABLE KEYS */;
/*!40000 ALTER TABLE `log_activity` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `log_session`
--

DROP TABLE IF EXISTS `log_session`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `log_session` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date_connexion` datetime(6) DEFAULT NULL,
  `date_deconnexion` datetime(6) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FKpesweraixtga75rqbhuepb5un` (`user_id`),
  CONSTRAINT `FKpesweraixtga75rqbhuepb5un` FOREIGN KEY (`user_id`) REFERENCES `user` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=25 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `log_session`
--

LOCK TABLES `log_session` WRITE;
/*!40000 ALTER TABLE `log_session` DISABLE KEYS */;
INSERT INTO `log_session` VALUES (15,'2020-04-10 16:09:59.019000','2020-04-10 16:10:19.203000',46),(16,'2020-04-10 16:10:32.079000','2020-04-10 16:10:52.893000',46),(17,'2020-04-10 16:11:30.340000','2020-04-10 16:12:03.600000',46),(18,'2020-04-11 12:25:44.707000','2020-04-11 12:26:07.875000',75),(19,'2020-04-11 12:27:07.019000','2020-04-11 12:27:32.396000',75),(20,'2020-04-11 12:28:18.192000','2020-04-11 12:34:07.988000',75),(21,'2020-04-11 12:34:21.014000','2020-04-11 12:34:43.183000',46),(22,'2020-04-11 12:34:59.908000',NULL,75),(23,'2020-04-11 12:47:34.474000','2020-04-11 12:48:18.934000',78),(24,'2020-04-11 12:48:28.599000',NULL,78);
/*!40000 ALTER TABLE `log_session` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `profile`
--

DROP TABLE IF EXISTS `profile`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `profile` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `libelle` varchar(255) DEFAULT NULL,
  `role` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `profile`
--

LOCK TABLES `profile` WRITE;
/*!40000 ALTER TABLE `profile` DISABLE KEYS */;
INSERT INTO `profile` VALUES (1,'parent','ROLE_PARENT'),(2,'eleve','ROLE_ELEVE');
/*!40000 ALTER TABLE `profile` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `qcm`
--

DROP TABLE IF EXISTS `qcm`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `qcm` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `listchoices` varchar(255) DEFAULT NULL,
  `question` varchar(255) DEFAULT NULL,
  `response` varchar(255) DEFAULT NULL,
  `exercice_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FKhxqh5yj3xwcth02qi1scimfg4` (`exercice_id`),
  CONSTRAINT `FKhxqh5yj3xwcth02qi1scimfg4` FOREIGN KEY (`exercice_id`) REFERENCES `exercice` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `qcm`
--

LOCK TABLES `qcm` WRITE;
/*!40000 ALTER TABLE `qcm` DISABLE KEYS */;
/*!40000 ALTER TABLE `qcm` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `qr`
--

DROP TABLE IF EXISTS `qr`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `qr` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `question` varchar(255) DEFAULT NULL,
  `response` varchar(255) DEFAULT NULL,
  `exercice_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK16mgci74iipv2th2q8ji55v1k` (`exercice_id`),
  CONSTRAINT `FK16mgci74iipv2th2q8ji55v1k` FOREIGN KEY (`exercice_id`) REFERENCES `exercice` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `qr`
--

LOCK TABLES `qr` WRITE;
/*!40000 ALTER TABLE `qr` DISABLE KEYS */;
/*!40000 ALTER TABLE `qr` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `recommendation`
--

DROP TABLE IF EXISTS `recommendation`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `recommendation` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `contenu` varchar(255) DEFAULT NULL,
  `date` datetime(6) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK8cjedlqgad0a04kgviq1godt0` (`user_id`),
  CONSTRAINT `FK8cjedlqgad0a04kgviq1godt0` FOREIGN KEY (`user_id`) REFERENCES `user` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `recommendation`
--

LOCK TABLES `recommendation` WRITE;
/*!40000 ALTER TABLE `recommendation` DISABLE KEYS */;
/*!40000 ALTER TABLE `recommendation` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tchat`
--

DROP TABLE IF EXISTS `tchat`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tchat` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date_send` varchar(255) DEFAULT NULL,
  `message` varchar(255) DEFAULT NULL,
  `reveiver_id` int(11) DEFAULT NULL,
  `transmitter_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FKq68imj4bwyg1uw03she05ymeo` (`reveiver_id`),
  KEY `FK3sor9xyl3blvn0kbd2im0wmsx` (`transmitter_id`),
  CONSTRAINT `FK3sor9xyl3blvn0kbd2im0wmsx` FOREIGN KEY (`transmitter_id`) REFERENCES `user` (`id`),
  CONSTRAINT `FKq68imj4bwyg1uw03she05ymeo` FOREIGN KEY (`reveiver_id`) REFERENCES `user` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tchat`
--

LOCK TABLES `tchat` WRITE;
/*!40000 ALTER TABLE `tchat` DISABLE KEYS */;
/*!40000 ALTER TABLE `tchat` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user`
--

DROP TABLE IF EXISTS `user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `email` varchar(255) DEFAULT NULL,
  `facebook` varchar(255) DEFAULT NULL,
  `firstname` varchar(255) DEFAULT NULL,
  `lastname` varchar(255) DEFAULT NULL,
  `twitter` varchar(255) DEFAULT NULL,
  `compte_id` int(11) DEFAULT NULL,
  `parent_id` int(11) DEFAULT NULL,
  `level` varchar(255) DEFAULT NULL,
  `parent_relation` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK55wqyp3yo78bxyge0cuswgjeg` (`compte_id`),
  KEY `FK4k8a1qa0wofm01aijepmu0d4g` (`parent_id`),
  CONSTRAINT `FK4k8a1qa0wofm01aijepmu0d4g` FOREIGN KEY (`parent_id`) REFERENCES `user` (`id`),
  CONSTRAINT `FK55wqyp3yo78bxyge0cuswgjeg` FOREIGN KEY (`compte_id`) REFERENCES `compte` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=80 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user`
--

LOCK TABLES `user` WRITE;
/*!40000 ALTER TABLE `user` DISABLE KEYS */;
INSERT INTO `user` VALUES (46,'karim.dahdouh.fr@gmail.com','kkk','karim','dahdouh','kkkk',25,NULL,NULL,NULL),(50,NULL,NULL,'student1P','student1N',NULL,NULL,46,'La quatrième (4e)','Father'),(51,NULL,NULL,'oopp','llll',NULL,NULL,46,'Cours moyen deuxième année (CM2)','Mother'),(52,NULL,NULL,'kkkkkk','kkkkp',NULL,NULL,46,'Cours moyen deuxième année (CM2)','Mother'),(53,NULL,NULL,'p1','n1',NULL,NULL,46,'La sixième (6e)','Mother'),(54,NULL,NULL,'p1','n1',NULL,NULL,46,'La sixième (6e)','Mother'),(55,NULL,NULL,'p1','n1',NULL,NULL,46,'La sixième (6e)','Mother'),(56,NULL,NULL,'p2','n2',NULL,NULL,46,'Cours moyen première année (CM1)','Autre'),(57,NULL,NULL,'p2','n2',NULL,NULL,46,'Cours moyen première année (CM1)','Autre'),(58,NULL,NULL,'p33','n33',NULL,26,46,'Cours élémentaire deuxième année (CE2)','Autre'),(59,NULL,NULL,'p333','n333',NULL,28,46,'La sixième (6e)','Mother'),(60,NULL,NULL,'p4','n4',NULL,30,46,'Cours préparatoire (CP)','Mother'),(61,NULL,NULL,'p4','n4',NULL,31,46,'Cours préparatoire (CP)','Mother'),(62,NULL,NULL,'p5','n5',NULL,32,46,'Cours moyen deuxième année (CM2)','Mother'),(63,NULL,NULL,'p5','n5',NULL,33,46,'Cours moyen deuxième année (CM2)','Mother'),(64,'yan.yasis@gmail.com','jkl','yan','yasin','jk',34,NULL,NULL,NULL),(65,'yan.yasis@gmail.comoo','jkloooo','yanooo','yasinooo','jkooo',35,NULL,NULL,NULL),(66,'yan.yasis@gmail.cpp','jklPPPP','yanPPPP','yasinPPPP','jkPPPP',36,NULL,NULL,NULL),(67,'yan.yasis@gmail.cpp','jklPPPP','yanPPPP','yasinPPPP','jkPPPP',37,NULL,NULL,NULL),(68,'karim.dahdouh.fr@gmail.com','oook','ooooppp','oooopppo','oookp',38,NULL,NULL,NULL),(69,'karim.dahdouh.fr@gmail.com','gjhk','test8','test8','gjhk',44,NULL,NULL,NULL),(70,'karim.dahdouh.fr@gmail.com','gjhk','test9','test9','gjhk',45,NULL,NULL,NULL),(71,'karim.dahdouh.fr@gmail.com','gjhk','test9','test9','gjhk',46,NULL,NULL,NULL),(72,'karim.dahdouh.fr@gmail.com','gjh10','test10','testA0','gjhk10',47,NULL,NULL,NULL),(73,'karim.dahdouh.fr@gmail.com','gjh10','test10','testA0','gjhk10',48,NULL,NULL,NULL),(74,'karim.dahdouh.fr@gmail.com','ghjk','theirno','barry','ghjk',49,NULL,NULL,NULL),(75,'karim.dahdouh.fr@gmail.com','fghjkl','theirno1','barry1','fghjk',50,NULL,NULL,NULL),(78,'barryzainoul14@gmail.com','ghjk','theirno5','barry5','hjkll',53,NULL,NULL,NULL),(79,NULL,NULL,'therino52','barry52',NULL,54,78,'Cours préparatoire (CP)','Father');
/*!40000 ALTER TABLE `user` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_course`
--

DROP TABLE IF EXISTS `user_course`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_course` (
  `id_user` int(11) NOT NULL,
  `id_course` int(11) NOT NULL,
  KEY `FKsdlq9odlq12vlja73ckncijrn` (`id_course`),
  KEY `FKeux29b6gyunbcxlevu1g47yqs` (`id_user`),
  CONSTRAINT `FKeux29b6gyunbcxlevu1g47yqs` FOREIGN KEY (`id_user`) REFERENCES `user` (`id`),
  CONSTRAINT `FKsdlq9odlq12vlja73ckncijrn` FOREIGN KEY (`id_course`) REFERENCES `course` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_course`
--

LOCK TABLES `user_course` WRITE;
/*!40000 ALTER TABLE `user_course` DISABLE KEYS */;
/*!40000 ALTER TABLE `user_course` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-04-13  9:51:22
